package it.polito.dp2.BIB.sol3.service;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.BadRequestException;

import it.polito.dp2.BIB.ass3.DestroyedBookshelfException;
import it.polito.dp2.BIB.sol3.db.DB;
import it.polito.dp2.BIB.sol3.db.DBBS;
import it.polito.dp2.BIB.sol3.service.jaxb.Bookshelf;
import it.polito.dp2.BIB.sol3.service.jaxb.Bookshelves;
import it.polito.dp2.BIB.sol3.service.jaxb.Item;

public class Neo4jDBE implements DBBS{
	private Map<String, Bookshelf> bs;
	// private Map<String, BigInteger> itemMap;

	
	private DB db;
	private static Neo4jDBE n4jDbE = null;
//	private Map<Bookshelf, String> sb;

	private Neo4jDBE(DB n4jDb) {
		this.db = n4jDb;
		bs = new ConcurrentHashMap<>();
		// itemMap = new ConcurrentHashMap<>();
	}
	
	public static Neo4jDBE getNeo4jDB(DB n4jDb){
		if(n4jDbE == null)
			n4jDbE = new Neo4jDBE(n4jDb);
		return n4jDbE;
	}
	
	@Override
	public String createBookShelf(Bookshelf bookshelf) throws Exception {
		String name = bookshelf.getName();
		if(name == null)
			return null;
		if(bs.containsKey(name))
			throw new BadRequestException("Bookshelf already exist");
		bs.put(name, bookshelf);
		return name;
	}
	
	@Override
	public Bookshelves searchBookShelves(String keyword) throws Exception {
		Bookshelves bookshelvesO = new Bookshelves();
		List<Bookshelf> bookshelves = bookshelvesO.getBookshelf();
		for(Bookshelf b: bs.values()){
			if(b.getName().contains(keyword))
				bookshelves.add(b);
		}
		return bookshelvesO;
	}


	@Override
	public List<Item> getItems(String name) throws Exception {
		BigInteger count = bs.get(name).getReadNumbers().add(BigInteger.ONE);
		bs.get(name).setReadNumbers(count);
		return bs.get(name).getItem();
	}

	@Override
	public boolean addItem(Item item, String bookshelf) throws Exception {
		if(bs.get(bookshelf) == null)
			throw new DestroyedBookshelfException();
		for(Item i: bs.get(bookshelf).getItem()){
			if(i.getSelf().equals(item.getSelf()))
				throw new BadRequestException("Bookshelf already contains this element");
		}
		return bs.get(bookshelf).getItem().add(item);
	}

	@Override
	public boolean deleteItem(BigInteger item, String name) throws Exception {
		Item i = db.getItem(item);
		if(i == null)
			return false;
		Bookshelf bookshelf = bs.get(name);
		if(bookshelf == null)
			return false;
		for(Item i2: bookshelf.getItem()){
			if(i2.getSelf().equals(i.getSelf()))
				return bookshelf.getItem().remove(i2);
		}
		return false;
	}

	@Override
	public String deleteBookShelf(String bookshelf) throws Exception {
		if(!bs.containsKey(bookshelf))
			return null;
		Bookshelf b = bs.remove(bookshelf);
		return b.getName();
	}

	@Override
	public BigInteger deleteItem(BigInteger item) throws Exception {
		Item i = db.getItem(item);
		for(Bookshelf b: bs.values()){
			for(Item i2: b.getItem()){
				if(i2.getSelf().equals(i.getSelf()))
					b.getItem().remove(i2);
			}
		}
		return item;
	}

	@Override
	public BigInteger getBookShelfReads(String name) throws Exception {
		return bs.get(name).getReadNumbers();
	}


//	@Override
//	public Bookshelf updateBookshelf(String name, Bookshelf bookshelf) {
//		// TODO Auto-generated method stub
//		return null;
//	}


	@Override
	public Bookshelf getBookShelf(String name) throws Exception {
		if(!bs.containsKey(name))
			throw new Exception("Element not present");
		BigInteger readsNumber = bs.get(name).getReadNumbers();
		bs.get(name).setReadNumbers(readsNumber.add(BigInteger.ONE));
		return bs.get(name);
	}

	@Override
	public void updateBookshelfItem(Item item) {
		for(Bookshelf b: bs.values()){
			for(Item i2: b.getItem()){
				if(i2.getSelf().equals(item.getSelf())){
					b.getItem().remove(i2);
					b.getItem().add(item);
				}
			}
		}		
	}



}
